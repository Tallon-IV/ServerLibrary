/**
 * @author Gershon Fosu (gfosu1997@gmail.com)
 */
package talloniv.junit.networking;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import talloniv.networking.server.ServerBlockingThread;

class ServerTesting {

	private static ServerBlockingThread blockingServer = null;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		blockingServer = new ServerBlockingThread(8888, true);
		blockingServer.Start();
		System.out.println("Daemon:"+blockingServer.serverThread.isDaemon());
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		blockingServer.Stop();
		Thread.sleep(1000);
		System.out.println("Interrupted:"+blockingServer.serverThread.isInterrupted());
		System.out.println("Alive:"+blockingServer.serverThread.isAlive());
		
	}

	@Test
	void isOnlineTest() 
	{
		//fail("Not yet implemented");
		assertTrue(blockingServer.IsOnline(), "Server is not online.");
	}
	
	@Test
	void portTest() 
	{
		assertEquals(blockingServer.GetPort(), 8888);
	}

}
