package talloniv.networking;

public interface IProtocolMessage 
{
	public Object Extract();
	public Object Pack();
}
