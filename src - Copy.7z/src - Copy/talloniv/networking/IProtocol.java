package talloniv.networking;

public interface IProtocol 
{
	public boolean Verify(byte[] data);
	public IProtocolMessage Deserialise(byte[] data);
	public byte[] Serialise(IProtocolMessage data);
}
