package talloniv.networking.server;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import talloniv.networking.IProtocol;
import talloniv.networking.IProtocolMessage;

public class RemoteClientConnection implements IThreadedConnection
{
	private IServerTask serverTask;
	private IProtocol protocol;
	private RemoteClient client;
	
	public RemoteClientConnection(RemoteClient client, IProtocol protocol, 
			IServerTask serverTask)
	{
		client.setRemoteClientConnection(this);
		this.client = client;
		this.protocol = protocol;
		this.serverTask = serverTask;
	}
	
	public RemoteClient getClient()
	{
		return client;
	}
	
	@Override
	public void run() 
	{
		try 
		{
			byte buffer[] = new byte[2048];
			int bytes = -1;
			InputStream in = client.GetSocket().getInputStream();
			while (true)
			{
				bytes = in.read(buffer);
				if (bytes < 1)
				{
					continue;
				}
				
				if (!protocol.Verify(buffer))
				{
					System.out.println("Malformed message");
					continue;
				}
				
				serverTask.OnDataReceived(client, protocol.Deserialise(buffer));
			}
		}
		catch (IOException e) 
		{
			System.out.println(e.getMessage());
			serverTask.OnDisconnected(client);
		}
		
	}
	
	@Override
	public void Send(IProtocolMessage message) 
	{
		try 
		{
			OutputStream out = client.GetSocket().getOutputStream();
			out.write(protocol.Serialise(message));
			out.flush();
			serverTask.OnDataSent(client, message);
		} 
		catch (IOException e) 
		{
			System.out.println(e.getMessage());
			serverTask.OnDisconnected(client);
		}
	}
	
	public static class RemoteClientConnectionFactory
	{
		private IProtocol protocol;
		private IServerTask serverTask;
		
		public RemoteClientConnectionFactory(IProtocol protocol, IServerTask serverTask)
		{
			this.protocol = protocol;
			this.serverTask = serverTask;
		}
		
		public RemoteClientConnection SpawnConnection(RemoteClient client)
		{
			return new RemoteClientConnection(client, protocol, serverTask);
		}
	}

}
