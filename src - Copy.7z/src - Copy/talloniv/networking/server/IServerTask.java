package talloniv.networking.server;

import talloniv.networking.IProtocolMessage;

public interface IServerTask 
{
	public boolean OnConnect(RemoteClient client);
	public void OnConnected(RemoteClient client);
	public void OnDataReceived(RemoteClient client, IProtocolMessage data);
	public void OnDataSent(RemoteClient client, IProtocolMessage data);
	public void OnDisconnected(RemoteClient client);
}
