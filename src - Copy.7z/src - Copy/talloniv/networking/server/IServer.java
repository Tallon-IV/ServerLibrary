package talloniv.networking.server;

import talloniv.networking.IProtocol;

public interface IServer extends Runnable 
{
	public void Start();
	public void Stop();
	public void SetProtocol(IProtocol protocol);
	public void AddServerTask(IServerTask task);
	public void RemoveServerTask(IServerTask task);
	public void RemoveServerTaskByClass(Class<IServerTask> taskClass);
	public boolean IsOnline();
	public String GetIp();
	public int GetPort();
	public int GetActiveConnectionsCount();
	public int GetRemoteClients(); //????
	public long GetOnlineTime();
}
