package talloniv.networking.server;

import java.net.Socket;

import talloniv.networking.IProtocolMessage;

public interface IRemoteClient 
{
	public Socket GetSocket();
	
	public String GetIpAddress();
	
	public int GetPort();
	
	public long GetConnectedWhen();
	
	public long GetConnectionTime();
	
	public void Send(IProtocolMessage msg);
}
