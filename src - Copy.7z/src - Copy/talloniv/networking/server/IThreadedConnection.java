package talloniv.networking.server;

import talloniv.networking.IProtocolMessage;

public interface IThreadedConnection extends Runnable
{
	public void Send(IProtocolMessage message);
}
