package talloniv.networking.server;

import java.net.Socket;

import talloniv.networking.IProtocolMessage;

public class RemoteClient implements IRemoteClient
{
	private Socket socket;
	private RemoteClientConnection connection = null;
	private String ipAddress;
	private int port;
	private long connectedWhen;
	private long connectionTime;
	
	public RemoteClient(String ipAddress, int port)
	{
		RemoteClient(ipAddress, port);
	}
	
	public RemoteClient(Socket socket)
	{
		this.socket = socket;
		RemoteClient(socket.getInetAddress().getHostAddress(), socket.getPort());
	}

	private void RemoteClient(String ipAddress, int port) 
	{
		this.ipAddress = ipAddress;
		this.port = port;
		this.connectedWhen = System.currentTimeMillis();
		this.connectionTime = 0;
	}
	
	void setRemoteClientConnection(RemoteClientConnection connection)
	{
		this.connection = connection;
	}
	
	public Socket GetSocket()
	{
		return socket;
	}
	
	public String GetIpAddress()
	{
		return ipAddress;
	}
	
	public int GetPort()
	{
		return port;
	}
	
	public long GetConnectedWhen()
	{
		return connectedWhen;
	}
	
	public long GetConnectionTime()
	{
		return connectionTime;
	}
	
	public void updateConnectionTime()
	{
		connectionTime = System.currentTimeMillis() - connectedWhen;
	}

	@Override
	public void Send(IProtocolMessage msg) 
	{
		if (connection == null)
		{
			return;
		}
		
		connection.Send(msg);
	}
}
